/*Problem 6: Create a Scala program that will ask the following question to a customer: "What is your favorite movie of all times?".*/
import scala.io.StdIn._
object Ans6
{
	def main(args: Array[String])
	{
	import scala.io.StdIn._
    val favoriteMovie = readLine("What is your favorite movie of all times?")
    println(s"$favoriteMovie is totally awesome!")
	}
	}