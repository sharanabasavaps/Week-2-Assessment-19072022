/*Problem 1: Create a Scala program to reverse, and then format to upper case*/
object Ans1
{
	def main(args: Array[String])
	{
	val strToFormat ="https://www.google.com"
val reversedAndToUpperCase = strToFormat.reverse.toUpperCase()
println(s"$strToFormat reversed and then to upper case = $reversedAndToUpperCase")
	}
	}