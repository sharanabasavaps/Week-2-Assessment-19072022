/*Problem 7: Assume the following lexical coupon codes: &quot;A&quot;, &quot;BB&quot;, &quot;CCC&quot;, &quot;DDDD&quot;, &quot;EEEEE&quot;. Write a
Scala program to create a new set of coupon codes based on the above one. The format for each
coupon code should be as follows: &quot;coupon code - i&quot;, where the number i is derived from the length
of each corresponding coupon code.*/

object Ans7
{
	def main(args: Array[String])
	{
	val codes = Seq("A", "BB", "CCC", "DDDD", "EEEEE")
 val codesWithLength = codes.map { code => s"$code - ${code.length}"
 }

 codesWithLength.foreach(println(_))
	}
	}
