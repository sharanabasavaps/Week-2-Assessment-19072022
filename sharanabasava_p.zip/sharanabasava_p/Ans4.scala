/*Problem 4: Create a Scala program to find the 8th character in the String: "http://www.google.com".*/
object Ans4
{
	def main(args: Array[String])
	{
	 val str = "http://www.google.com"
    val charToFind = str.charAt(7)
    println(s"The 8th character literal in $str = $charToFind")
	}
	}